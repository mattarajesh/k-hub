import React, { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';
import { scaleOrdinal } from 'd3-scale';
import { schemeCategory10 } from 'd3-scale-chromatic';

const PieCharts = () => {
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    // Fetch data from API
    const fetchData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/data');
        const data = await response.json();
        setChartData(data);
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();
  }, []);

  const renderCharts = () => {
    if (!chartData) {
      return <p>Loading data...</p>;
    }

    const fieldCounts = chartData.reduce((acc, curr) => {
      // Count the occurrences of each field value
      Object.keys(curr).forEach((field) => {
        acc[field] = { ...acc[field], [curr[field]]: (acc[field]?.[curr[field]] || 0) + 1 };
      });
      return acc;
    }, {});

    // Generate a unique color scale for each field
    const colorScales = {};
    Object.keys(fieldCounts).forEach((fieldName, index) => {
      colorScales[fieldName] = scaleOrdinal(schemeCategory10.slice(index * 10, (index + 1) * 10));
    });

    return Object.entries(fieldCounts).map(([fieldName, fieldValueCounts], index) => {
      const pieChartData = Object.entries(fieldValueCounts).map(([value, count]) => ({
        name: value,
        value: count,
      }));

      const COLORS = pieChartData.map((entry) => colorScales[fieldName](entry.name));

      return (
        <div key={`chart-${index}`} className="chart-container">
          <h2>{fieldName}</h2>
          <PieChart width={500} height={400}>
            <Pie
              data={pieChartData}
              cx="50%"
              cy="50%"
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              labelLine={false}
            >
              {pieChartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Legend />
            <Tooltip />
          </PieChart>
        </div>
      );
    });
  };

  return <div className="total_box">{renderCharts()}</div>;
};

export default PieCharts;
