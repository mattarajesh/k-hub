import React, { useState } from 'react';
import '../css/Form.css';
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Form = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    country: '',
    favoritecricketplayer: '',
    favoritefootballplayer: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formDataWithIntAge = {
        ...formData,
        age: parseInt(formData.age)
      };

      await fetch('http://127.0.0.1:5000/api/submit-form', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formDataWithIntAge)
      });

      // Form data successfully sent to the backend
      console.log('Form data submitted successfully!');
      setFormData({
        name: '',
        age: '',
        country: '',
        favoritecar: '',
        favoritebike: ''
      });
      toast.success('Data Saved'); // Display success notification
    } catch (error) {
      // Handle error
      console.error('Error submitting form data:', error);
    }
  };

  return (
    <>
   
      <div className='navbor'>
        <div className="form-container">
          <form onSubmit={handleSubmit}>
            <label>
              Name:
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Age:
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleChange}
                required
              />
            </label>
            <label>
            Country:
            <select
              name="country"
              value={formData.country}
              onChange={handleChange}
              required
            >
              <option value="">Select a country</option>
              <option value="India">India</option>
              <option value="USA">USA</option>
              <option value="Canada">Canada</option>
              <option value="France">France</option>
              <option value="Italy">Italy</option>
              <option value="Spain">Spain</option>
              <option value="UK">UK</option>
              <option value="Austraila">Australia</option>
              <option value="Germany">Germany</option>
              <option value="Other">Other</option>
            </select>
          </label>
          <label>
            Favorite Car:
            <select
              name="favoritecricketplayer"
              value={formData.favoritecricketplayer}
              onChange={handleChange}
              required
            >
              <option value="">Select a favorite cricket player</option>
              <option value="ms_dhoni">Ms Dhoni</option>
              <option value="virat_kholi">Virat Kholi</option>
              <option value="chris_gayle">Chris Gayle</option>
              <option value="shikhar_dhawan">Shikhar Dhawan</option>
              <option value="ab_de_villiers">AB de Villiers</option>
              <option value="harbhajan_singh">Harbhajan Singh</option>
              <option value="yuvraj_singh">Yuvraj singh</option>
              <option value="rohit_sharma">Rohit sharma</option>
              <option value="Other">Other</option>
            </select>
          </label>
          <label>
            Favorite Bike:
            <select
              name="favoritefootballplayer"
              value={formData.favoritefootballplayer}
              onChange={handleChange}
              required
            >
              <option value="">Select a favorite football player</option>
              <option value="Cristiano Ronaldo">Cristiano Ronaldo</option>
              <option value="Lionel Messi">Lionel Messi</option>
              <option value="sunil chatri">sunil chatri</option>
              <option value="Ronaldinho">Ronaldinho</option>
              <option value="David Beckham">David Beckham</option>
              <option value=" Karim Benzema">Karim Benzema</option>
              <option value="Neymar Jr.">Neymar Jr.</option>
              <option value="Sergio Ramos">Sergio Ramos</option>
              <option value="Other">Other</option>

            </select>
          </label>
            {/* Rest of the form inputs */}
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
      <ToastContainer /> {/* Container for displaying notifications */}
    </>
  );
};

export default Form;
