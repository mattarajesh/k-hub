import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Cell } from 'recharts';
import { scaleOrdinal } from 'd3-scale';
import { schemeCategory10 } from 'd3-scale-chromatic';

const BarGraph = () => {
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    // Fetch data from API
    const fetchData = async () => {
      try {
        const response = await fetch('http://127.0.0.1:5000/data');
        const data = await response.json();
        setChartData(data);
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();
  }, []);

  const renderCharts = () => {
    if (!chartData) {
      return <p>Loading data...</p>;
    }

    const fieldCounts = chartData.reduce((acc, curr) => {
      // Count the occurrences of each field
      Object.keys(curr).forEach((field) => {
        acc[field] = { ...acc[field], [curr[field]]: (acc[field]?.[curr[field]] || 0) + 1 };
      });
      return acc;
    }, {});

    // Generate a unique color scale for each field
    const colorScales = {};
    Object.keys(fieldCounts).forEach((fieldName, index) => {
      colorScales[fieldName] = scaleOrdinal(schemeCategory10.slice(index * 10, (index + 1) * 10));
    });

    return Object.entries(fieldCounts).map(([fieldName, fieldValueCounts], index) => (
      <div key={`chart-${index}`} className="chart-container">
        <h2>{fieldName}</h2>
        <BarChart width={500} height={400} data={Object.entries(fieldValueCounts)}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="0" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="1" fill={colorScales[fieldName](fieldName)} />
        </BarChart>
      </div>
    ));
  };

  return <div className="total_box">{renderCharts()}</div>;
};

export default BarGraph;
