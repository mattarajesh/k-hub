const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const xlsx=require('xlsx')


// Enable CORS
app.use(cors());
const upload = multer({ dest: 'uploads/' });

// Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB using Mongoose
const mongodbUri = 'mongodb://127.0.0.1:27017/app';
mongoose.connect(mongodbUri, { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB successfully');
});

// Create a Mongoose schema for the data collection
const dataSchema = new mongoose.Schema({}, { strict: false });
const DataModel = mongoose.model('data', dataSchema);

// Route to submit form data
// Route to submit form data
app.post('/api/submit-form', async (req, res) => {
    const form_data = req.body;
    try {
      await DataModel.create(form_data);
      res.status(200).send('Form data submitted successfully!');
    } catch (err) {
      console.error('Error submitting form data:', err);
      res.status(500).send('Failed to submit form data');
    }
  });
  

// Route to upload data from an Excel file
app.post('/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
  
    // Read the Excel file and extract data
    const filePath = path.join(__dirname, req.file.path);
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
  
    // Save the data to MongoDB
    try {
      await DataModel.insertMany(sheetData);
      res.json({ message: 'Data uploaded to MongoDB successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to save data to MongoDB' });
    }
  });
// Route to retrieve data from the database
// Route to retrieve data from the database
app.get('/data', async (req, res) => {
    try {
      const documents = await DataModel.find({}, { _id: 0 });
      // Process the data as needed
      // ...
  
      res.status(200).json(documents);
    } catch (err) {
      console.error('Error retrieving data:', err);
      res.status(500).json({ message: 'Failed to retrieve data' });
    }
  });
  

const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
